-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 16, 2020 at 12:23 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lifestylestore`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `contact` bigint(11) NOT NULL,
  `city` varchar(50) NOT NULL,
  `address` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `contact`, `city`, `address`) VALUES
(1, 'sona', 'sona@gmail.com', 'sona@123', 99999999, 'delhi', 'gurgaon'),
(2, '', 'bhanu@gmail.com', '199ada3aa599dc5c65e312ff60b7c1a1', 9968729999, 'Delhi', 'West Delhi'),
(3, '', 'pratap@gmail.com', '265e121c2d3f4864cfc36fa78580ae88', 9868780799, 'Delhi', 'North Delhi'),
(4, 'admin', 'admin@gmail.com', 'e6e061838856bf47e1de730719fb2609', 9717895531, 'Delhi', 'South Delhi'),
(5, 'xyz', 'xyz@gmail.com', '742f40cbb203f3b2c879a72a2828dac1', 9966887722, 'Mumbai', 'aurangabad'),
(6, 'mno', 'mno@gmail.com', '892afebfe010f508341ab474261e5856', 9911223344, 'Punjab', 'chandigarh');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE IF NOT EXISTS `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `price`) VALUES
(1, 'iPhone 11', 36000),
(2, 'iPhone 12', 40000),
(3, 'iPhone xs', 50000),
(4, 'iphone', 50000),
(5, 'iPhone 4', 40000),
(6, 'Realme 2', 40000),
(7, 'iPhone XR', 50000),
(8, 'Realme U1', 50000),
(9, 'iPhone 11 Pro', 36000),
(10, 'Realme 5', 40000),
(11, 'Redmi Note 5', 9500),
(12, 'Samsung 1', 8300);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `contact`, `city`, `address`) VALUES
(1, 'Rahul Sen', 'rahul@123', '123', '9831448923', 'kolkata', 'barrckpore'),
(2, 'Ruchi Nag', 'ruchi@123', '123', '9856448923', 'kolkata', 'sodepur'),
(3, 'Rahi Das', 'rahi@123', '123', '9831448944', 'kolkata', 'barrckpore'),
(4, 'Amit Das', 'amit@456', '456', '9831448998', 'delhi', 'noida'),
(5, 'Sudi Roy', 'sudi@456', '456', '9831588923', 'chennai', 'central'),
(6, 'Naru Ghosh', 'nimo@123', '123', '8931448923', 'guwahati', 'tezpur'),
(7, 'Shilpi Dutta', 'shilpi@456', '456', '8934548923', 'kolkata', 'baruipur'),
(8, 'Loku Sen', 'loku@789', '789', '9831457823', 'kolkata', 'bally'),
(9, 'Kuheli Dey', 'kuhu@789', '789', '9831448932', 'kolkata', 'srerampur'),
(10, 'Priya Sen', 'priya@147', '147', '9831446623', 'kolkata', 'barrckpore'),
(11, 'Priya Kumar', 'priya@123', '123', '9888448923', 'kolkata', 'srerampur'),
(12, 'Dev Mallo', 'dev@159', '159', '9903604023', 'kolkata', 'dumdum'),
(13, 'Riya Sen', 'riya753', '753', '9831586446', 'kolkata', 'behala'),
(14, 'vilas', 'abc@gmail.com', '0c76e9832e376ec0539f1b0d45dfab57', '8108495022', 'MUMBAI', 'mumbai'),
(15, 'vilas', 'vil@gmail.com', '4337721e6c4299cbf70573bcd6d0082c', '8108495022', 'mumbai', 'mumbai'),
(16, 'vilas', 'xyz@gmail.com', '4337721e6c4299cbf70573bcd6d0082c', '8108495022', 'mum', 'mum'),
(17, 'Akansh Singhal', 'akanshsinghal7@gmail.com', '25f9e794323b453885f5181f1b624d0b', '8267833395', 'Ghaziabad', 'Aryabhatt Hostel KIET Muradnagar, Ghazaiabad, Ghazaiabad'),
(18, 'Abc', 'abc123@gmail.com', 'e99a18c428cb38d5f260853678922e03', '8939350499', 'Delhi', '123, New friend colony'),
(19, 'ABC', 'abc456@gmail.com', '53e6086284353cb73d4979f08537d950', '9999999999', 'Delhi', 'aaaaaaaaaaaaaaaa'),
(20, 'Sonal', 'sonal@gmail.com', '3598146b36e9cff34f37531f05e56b04', '9999999999', 'Delhi', 'Gurgaon'),
(21, 'Sona', 'sona@gmail.com', '1e18c1fb31377d5a7a61b83d339db50b', '9999999999', 'Delhi', 'bobobobbobo'),
(22, 'tutu', 'tutu@gmail.com', '93903b9c045e596da0814d225c79965b', '9968729991', 'Delhi', 'akshardham');

-- --------------------------------------------------------

--
-- Table structure for table `users_items`
--

DROP TABLE IF EXISTS `users_items`;
CREATE TABLE IF NOT EXISTS `users_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `status` enum('Added to cart','Confirmed') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`),
  KEY `users_id` (`users_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_items`
--

INSERT INTO `users_items` (`id`, `users_id`, `item_id`, `status`) VALUES
(1, 1, 1, 'Added to cart'),
(2, 2, 2, 'Added to cart'),
(3, 3, 3, 'Added to cart'),
(4, 4, 4, 'Added to cart'),
(5, 6, 6, 'Added to cart'),
(6, 5, 5, 'Added to cart'),
(7, 7, 7, 'Added to cart'),
(8, 8, 8, 'Added to cart'),
(9, 9, 9, 'Added to cart'),
(10, 10, 10, 'Added to cart'),
(11, 11, 11, 'Added to cart'),
(12, 1, 6, 'Confirmed'),
(13, 5, 2, 'Confirmed'),
(14, 7, 2, 'Confirmed'),
(15, 11, 5, 'Confirmed'),
(16, 12, 11, 'Added to cart'),
(18, 17, 2, 'Confirmed'),
(20, 17, 2, 'Confirmed'),
(22, 17, 1, 'Confirmed'),
(23, 17, 2, 'Confirmed'),
(24, 18, 3, 'Confirmed'),
(25, 18, 2, 'Confirmed'),
(26, 18, 11, 'Confirmed'),
(27, 18, 3, 'Confirmed'),
(28, 18, 4, 'Confirmed'),
(29, 18, 2, 'Added to cart'),
(30, 18, 1, 'Added to cart'),
(31, 19, 1, 'Confirmed'),
(33, 19, 1, 'Added to cart'),
(34, 21, 1, 'Added to cart'),
(35, 21, 2, 'Added to cart'),
(36, 21, 3, 'Added to cart');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users_items`
--
ALTER TABLE `users_items`
  ADD CONSTRAINT `users_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`),
  ADD CONSTRAINT `users_items_ibfk_2` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
