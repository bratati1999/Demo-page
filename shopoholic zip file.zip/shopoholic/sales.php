<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
	
    <title>Admin Area | Sales</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style1.css" rel="stylesheet">
    <script src="http://cdn.ckeditor.com/4.6.1/standard/ckeditor.js"></script>
  </head>
  <body>

    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#"><h3>Shop-O-Holic</h3></a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li><a href="admin_dash.php">Dashboard</a></li>
            <li><a href="users.php">Users</a></li>
            
            <li class="active"><a href="sales.php">Sales</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="#"><br>Welcome,Admin!!</a></li>
            <li><a href="index.php"><br>Logout</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <header id="header">
      <div class="container">
        <div class="row">
          <div class="col-md-10">
            <h1><span class="glyphicon glyphicon-cog" aria-hidden="true"></span> Sales</h1>
          </div>
          
        </div>
      </div>
    </header>

    <section id="breadcrumb">
      <div class="container">
        <ol class="breadcrumb">
          <li><a href="admin_dash.php">Dashboard</a></li>
          <li class="active">Sales</li>
        </ol>
      </div>
    </section>

    <section id="main">
      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <div class="list-group">
              <a href="admin_dash.php" class="list-group-item active main-color-bg">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span> Dashboard
              </a>
              <a href="products.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Buyers <span class="badge">12</span></a>
              <a href="sell.php" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Sellers <span class="badge">13</span></a>
              <a href="users.php" class="list-group-item"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> Users <span class="badge">20</span></a>
            </div>

            <div class="well">
              <h4>Disk Space Used</h4>
              <div class="progress">
                  <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">
                      60%
              </div>
            </div>
            <h4>Bandwidth Used </h4>
            <div class="progress">
                <div class="progress-bar" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%;">
                    40%
            </div>
          </div>
            </div>
          </div>
          <div class="col-md-9">
		  <div class="row">
                <div class="col-lg-9 mb-4">
                  <div class="card bg-primary text-white shadow">
                    <div class="card-body">
                      Moderate
                      <div class="text-white-50 small">Moderate Sales</div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-9 mb-4">
                  <div class="card bg-success text-white shadow">
                    <div class="card-body">
                      High
                      <div class="text-white-50 small">Sales are going well</div>
                    </div>
                  </div>
                </div>
				<div class="col-lg-9 mb-4">
                  <div class="card bg-info text-white shadow">
                    <div class="card-body">
                      Intermediate
                      <div class="text-white-50 small">Sales are increasing</div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-9 mb-4">
                  <div class="card bg-warning text-white shadow">
                    <div class="card-body">
                      Warning
                      <div class="text-white-50 small">Sales are quite low</div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-9 mb-4">
                  <div class="card bg-danger text-white shadow">
                    <div class="card-body">
                      Danger
                      <div class="text-white-50 small">Sales are very less</div>
                    </div>
                  </div>
                </div>
                
              </div>
			  <br><br>
            <!-- Website Overview -->
            <!---<div class="card shadow mb-4">
                <div class="card-header py-3">--->
                  <h3 class="text-primary">Projects</h3>
                </div>
                <div class="card-body">
                  <h4 class="small font-weight-bold">January<span class="float-right">20%</span></h4>
                  <div class="progress mb-4">
                    <div class="progress-bar bg-danger" role="progressbar" style="width: 20%" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  <h4 class="small font-weight-bold">February <span class="float-right">40%</span></h4>
                  <div class="progress mb-4">
                    <div class="progress-bar bg-warning" role="progressbar" style="width: 40%" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  <h4 class="small font-weight-bold">March <span class="float-right">60%</span></h4>
                  <div class="progress mb-4">
                    <div class="progress-bar bg-primary " role="progressbar" style="width: 60%" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  <h4 class="small font-weight-bold">April <span class="float-right">80%</span></h4>
                  <div class="progress mb-4">
                    <div class="progress-bar bg-info" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  <h4 class="small font-weight-bold">May <span class="float-right">95%</span></h4>
                  <div class="progress">
                    <div class="progress-bar bg-success" role="progressbar" style="width: 95%" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                </div>
              </div>
				
				
          </div>
        </div>
      </div>
    </section>
	<br><br><br><br>
	<?php
        include 'includes/footer.php';
        ?>
    <!---<footer id="footer">
      <p>Copyright Bratati Sen, &copy; 2020</p>
    </footer>--->

    <!-- Modals -->

    

  <script>
     CKEDITOR.replace( 'editor1' );
 </script>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>

