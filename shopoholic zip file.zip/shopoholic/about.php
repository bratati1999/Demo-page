<?php
require("includes/common.php");

// Redirects the user to products page if he/she is logged in.
//if (isset($_SESSION['email'])) //{
 // header('location: products.php');
//}

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Welcome | Shop-O-Holic Store</title>
		<!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
        <!-- Custom CSS -->
        <link href="css/style.css" rel="stylesheet" type="text/css">
        <!-- jQuery -->
        <script type="text/javascript" src="js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script type="text/javascript" src="js/bootstrap.min.js"></script>
		</head>
		<body style="padding-top: 50px;">
        <!-- Header -->
        <?php
        include 'includes/header.php';
        ?>
        <!--Header end-->

       <body>
	   <p><h3>Hi!</h3>This is Shop-O-Holic store where you can buy the smartest of the smartphone at best prices!! </p>
	   <p>The owner of this site is BRATATI SEN.</p>
	   </body>
	</head>
</html>